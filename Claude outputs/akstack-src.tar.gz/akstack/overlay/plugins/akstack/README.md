# akstack plugin

The plugin directory for akstack (see the repository README). Rebuilt by `tools/vendor.py` from the pinned sources in `tools/sources.json`; do not edit vendored skills here by hand (fix the mapping, the overlay, or the upstream, then rerun). Hand-written files live in `overlay/` and win on every rebuild.
