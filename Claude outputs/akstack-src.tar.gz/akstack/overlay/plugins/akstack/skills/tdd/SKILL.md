---
name: tdd
description: "Test-driven development for both shapes of work: a failing regression test before a bug fix, and the red-green loop for building a feature test-first at agreed seams. Use when the user asks for TDD, a failing test, a regression test, red-green-refactor, integration tests, or test-first work, OR when a bug has an obvious cheap local test target. Skip when the test path is unclear, expensive, integration-heavy, or not requested; verify on the real artifact instead."
---

# TDD

On Codex, read the [platform mapping](../poteto-mode/references/codex-tools.md), including its per-skill notes, before following this skill.

Merged from pstack's `tdd` (the bug-fix regression workflow) and Matt Pocock's `tdd` (what a good test is, seams, anti-patterns, the rules of the loop). The two halves share one rule: red before green, and the failure must prove the test measures the thing.

When exploring the codebase, read `GLOSSARY.md` if it exists so test names and interface vocabulary match the project's domain language, and respect ADRs in the area you are touching.

## What a good test is

Tests verify behavior through public interfaces, not implementation details. Code can change entirely; tests should not. A good test reads like a specification ("user can checkout with valid cart"), names a capability, and survives refactors because it does not care about internal structure. Examples and the mocking rules are in [references/merged/tdd/tests.md](references/merged/tdd/tests.md) and [references/merged/tdd/mocking.md](references/merged/tdd/mocking.md).

## Seams: where tests go

A seam is the public boundary you test at: the interface where you observe behavior without reaching inside. Tests live at seams, never against internals. Before writing any test for feature work, write down the seams under test and confirm them with the user; you cannot test everything, so agreeing the seams up front is how effort lands on critical paths and complex logic. When the shape of the interface is itself in question, use the `codebase-design` skill for the module, interface, depth and seam vocabulary.

## Anti-patterns

- Implementation-coupled: mocks internal collaborators, tests private methods, or verifies through a side channel. The tell: the test breaks on a refactor that changed no behavior.
- Tautological: the assertion recomputes the expected value the way the code does, so it passes by construction. Expected values come from an independent source: a known-good literal, a worked example, the spec.
- Horizontal slicing: all tests first, then all implementation. Work in vertical slices: one test, one implementation, repeat, each test a tracer bullet that responds to what the last cycle taught you.
- A bad test is worse than no test: one that mostly tests mocks, encodes implementation details, depends on timing or global state, needs expensive infrastructure for a small fix, or would be deleted right after proving the fix.

## Fixing a bug

1. Understand the bug: intended behavior, current behavior, affected path, smallest observable reproduction.
2. Choose the narrowest executable check, preferring the closest unit, component, integration or regression test already used for that codepath. If no practical path is obvious, do not invent one to satisfy the workflow.
3. Write the failing test first: the smallest focused test that would have caught the bug, encoding intended behavior, not the current implementation.
4. Run it before fixing and quote the failure content, not the assertion line: an exception, an empty result against a literal, and the predicted mismatch all print red, and only the last one proves the test measures the bug. A pass, or a failure for an unrelated reason, means fix the test or the reproduction before touching the implementation.
5. Make the smallest production change that satisfies the intended behavior while preserving nearby contracts.
6. Rerun; confirm green.

When a failing test is impractical, use the closest executable regression check instead: a targeted script, a manual reproduction command, the project's `verify` skill, a snapshot comparison, a log assertion, a focused integration check.

## Building a feature

Red before green: write the failing test at an agreed seam, then only enough code to pass it. One seam, one test, one minimal implementation per cycle. Do not anticipate future tests or add speculative features. Refactoring is not part of the loop; it belongs to review (the `interrogate` skill), after the cycle is green.

## Guardrails

- Never change a test merely to match a wrong implementation, and never weaken an assertion unless the expected behavior changed and the reason is clear.
- Keep a regression test focused on the bug; no broad fixture churn or unrelated coverage.
- Make flaky signals deterministic where possible and say what is being locked down.
- If a bug exposes a class of failures, land the focused regression path first, then consider sibling coverage.

## Final response

Report the evidence, not just the outcome: name the failing-before test or check and quote the failure trimmed to the diff; name the passing-after run and any nearby validation; if failing-before evidence could not be demonstrated, say why and name the closest regression check used instead.
