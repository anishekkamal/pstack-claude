---
name: lfg
description: "Take one request all the way to done, hands-off, through the akstack skills whose job each step is: scope if ambiguous, plan, build through poteto-mode, simplify, review, record the learning, prove it in the running app, open the PR, watch CI. Use only when the user explicitly asks for autonomous end-to-end work or invokes lfg. For a queue of many PRs use poteto-mode's autopilot playbooks; for step-by-step work use plan, poteto-mode or the opening-a-pr playbook directly."
argument-hint: "[feature, bug, issue reference, or plan path]"
---

# lfg

Compound Engineering's `lfg` pipeline, re-pointed at the akstack skills that now own each step. Its original intake rules, return contracts and shipping close-out are in `references/merged/lfg/` and still govern the shape of each hand-off; read `references/merged/lfg/SOURCE.md` once before the first run and `references/merged/lfg/references/intake.md` before routing.

**Outcome.** A code change ends as an open pull request whose URL you hold, with CI decided, after being implemented, simplified, reviewed with eligible findings applied and the rest recorded, its durable learning captured, proven in the running app where one exists, committed and pushed. Merging stays with the user unless they granted it for this run. A request whose result is not a code change ends with the owning skill's result and no branch.

**Interaction.** Ask the user only through `brainstorm`, and only when a human is present. Everything else proceeds: reversible work is done and shown for correction afterwards; only an irreversible action outside what was granted (a merge, a force-push, deleting data) stops. Resolve every skill below against the host's skill list and invoke that entry (`akstack:plan` and so on).

## Route

- A plan path, or a plan `plan` wrote this session → the plan route below.
- A concrete report of failing or wrong behavior → `poteto-mode` with the bug-fix playbook; its fix is the implementation, then continue at step 3.
- A change that hangs on a judgment the user did not settle → `pov` first; continue only on a verdict that supports the change.
- Product shape with more than one plausible reading → `brainstorm` when a human is present, otherwise `plan` in pipeline mode.
- A result that is not a code change → the owning skill (`how`, `why`, `pov`, `ideate`, the prototype playbook) and end with its result.
- Any other change → `plan`.

When unsure, take the route that asks more of the evidence.

## The run

1. **Work source.** `plan` writes or confirms an implementation-ready plan (readiness check in `references/merged/lfg/references/plan-brief.md`). A `blocked` return stops the run and is never retried.
2. **Build.** `poteto-mode`, feature playbook, from the plan path. Only a complete, evidenced return advances.
3. **Simplify.** `deslop` on the branch diff; skip for docs-only or sub-10-line changes.
4. **Review.** `interrogate` on the diff with the plan as context. A finding that shows a settled decision cannot work stops the run as blocked.
5. **Apply and persist review fixes.** Commit them; nothing proceeds with eligible fixes sitting uncommitted. Record every unapplied actionable finding durably (PR body, ticket, or the DONE report) before DONE.
6. **Learning.** `compound` in non-interactive mode when the run produced reasoning the code, tests and plan do not carry. "Documentation skipped" is a success.
7. **Prove it.** When the repo has a `verify` skill (see `verify-web`), drive the changed flow and attach the verdict and evidence path to the PR body. No harness: say so in the PR body rather than claiming it was exercised.
8. **Ship.** The opening-a-pr playbook from `poteto-mode`: small ordered commits, evidence in the description, push, PR URL. `git remote` empty means local-only: commit everything, skip every push and PR step, and treat that as terminal.
9. **Watch.** `babysit` to CI-decided when a PR exists; it stops at merge-ready and never merges.
10. Output `<promise>DONE</promise>` after the close-out in `references/merged/lfg/references/shipping.md`.

**Stop, and say why, when** the work source cannot be produced, a child return is anything but complete and evidenced, a settled decision is invalidated, or a project-defined shipping process falls short. A stop leaves nothing pushed that was not already pushed.
