<EXTREMELY_IMPORTANT>
You have akstack.

Invoke the `akstack:poteto-mode` skill and follow its instructions when a task meets any of these:

- it touches more than one file, or changes a signature other files call
- it involves a design or architecture choice
- it is a bug whose cause is not yet known, or a performance issue

It routes to the right akstack skill from there. For smaller tasks, such as a contained change to one file with an obvious test, a question, or a one-line edit, work directly and verify on the real artifact.

When the intent is already specific, enter that skill directly: `akstack:brainstorm` to scope what to build, `akstack:plan` to write the plan, `akstack:grilling` to stress-test a decision, `akstack:to-spec` and `akstack:to-tickets` to publish work to the tracker, `akstack:tdd`, `akstack:architect`, `akstack:how`, `akstack:why`, `akstack:arena`, `akstack:interrogate`, `akstack:verify-web` to prove a web change with evidence, `akstack:compound` to record a learning, `akstack:checkpoint` to save or resume working state.

Before saying a change works, prove it on the real artifact; for a web UI that means the project's `verify` skill (set up once with `akstack:verify-web`). User instructions (CLAUDE.md, AGENTS.md, direct requests) take precedence. Other session-start mandates still apply; when a task meets the criteria above they route implementation through poteto-mode.
</EXTREMELY_IMPORTANT>
