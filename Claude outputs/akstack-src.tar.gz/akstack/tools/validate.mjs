#!/usr/bin/env node
// Static checks for the built plugin. Exit 1 on any failure, with every problem listed.
//   node tools/validate.mjs
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const PLUGIN = join(ROOT, "plugins", "akstack");
const SKILLS = join(PLUGIN, "skills");
const MAPPING = JSON.parse(readFileSync(join(ROOT, "tools", "mapping.json"), "utf8"));
const problems = [];
const warnings = [];
// Hand-written skills from overlay/ name their merged sources on purpose.
const OVERLAY_SKILLS = new Set(readdirSync(join(ROOT, "overlay", "plugins", "akstack", "skills")));
// Upstream template docs whose example links are illustrative, not real paths.
const LINK_EXEMPT = [/\/domain-modeling\/GLOSSARY-FORMAT\.md$/, /\/wayfinder\/SKILL\.md$/];
const stripFences = (text) => text.replace(/```[\s\S]*?```/g, "");
const stripMergedLines = (text) => text.split("\n").filter((l) => !/references\/merged\/|Merged sources|Merged routing/.test(l)).join("\n");

function walk(dir) {
  return readdirSync(dir, { withFileTypes: true })
    .sort((a, b) => a.name.localeCompare(b.name))
    .flatMap((e) => (e.name === "node_modules" || e.name === ".git" ? [] : e.isDirectory() ? walk(join(dir, e.name)) : [join(dir, e.name)]));
}

function frontmatter(text) {
  const m = text.match(/^---\n([\s\S]*?)\n---\n/);
  if (!m) return null;
  const out = {};
  for (const line of m[1].split("\n")) {
    const kv = line.match(/^([A-Za-z-]+):\s*(.*)$/);
    if (kv) out[kv[1]] = kv[2].replace(/^"(.*)"$/, "$1");
  }
  return out;
}

// 1. skills: SKILL.md, frontmatter, name == dir, unique, no nested SKILL.md
const names = new Set();
for (const dir of readdirSync(SKILLS, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => e.name)) {
  const file = join(SKILLS, dir, "SKILL.md");
  if (!existsSync(file)) {
    problems.push(`${dir}: missing SKILL.md`);
    continue;
  }
  const fm = frontmatter(readFileSync(file, "utf8"));
  if (!fm) problems.push(`${dir}: SKILL.md has no frontmatter`);
  else {
    if (fm.name !== dir) problems.push(`${dir}: frontmatter name is "${fm.name}"`);
    if (!fm.description || fm.description.length < 20) problems.push(`${dir}: description missing or too short`);
    if (names.has(fm.name)) problems.push(`${dir}: duplicate skill name ${fm.name}`);
    names.add(fm.name);
    if (fm["disable-model-invocation"] === "true" && !dir.startsWith("principle-")) warnings.push(`${dir}: disable-model-invocation: true (the model cannot call it; intended?)`);
  }
  for (const f of walk(join(SKILLS, dir))) {
    if (f !== file && f.endsWith("/SKILL.md") && !f.includes("/templates/")) problems.push(`${relative(PLUGIN, f)}: nested SKILL.md would register as a skill; vendor.py renames merged copies to SOURCE.md`);
  }
}

// 2. markdown links resolve inside the plugin
for (const file of walk(PLUGIN).filter((f) => f.endsWith(".md") && !LINK_EXEMPT.some((rx) => rx.test(f)))) {
  const text = stripFences(readFileSync(file, "utf8"));
  for (const m of text.matchAll(/\]\(([^)\s]+)\)/g)) {
    const target = m[1];
    if (/^[a-z][a-z0-9+.-]*:/i.test(target) || target.startsWith("#")) continue;
    const path = decodeURIComponent(target.split(/[?#]/, 1)[0]);
    if (!path) continue;
    const resolved = resolve(dirname(file), path);
    if (!resolved.startsWith(PLUGIN)) problems.push(`${relative(PLUGIN, file)} -> ${target} (escapes the plugin)`);
    else if (!existsSync(resolved)) problems.push(`${relative(PLUGIN, file)} -> ${target} (missing)`);
  }
}

// 3. leftover references to merged or renamed names in skill prose (outside references/merged)
const oldNames = [
  ...Object.keys(MAPPING.ce.kept), ...Object.keys(MAPPING.ce.merged), ...MAPPING.ce.dropped,
  ...Object.keys(MAPPING.mp.merged).map((p) => p.split("/").pop()),
  ...Object.keys(MAPPING.mp.kept).map((p) => p.split("/").pop()).filter((n) => n !== MAPPING.mp.kept[Object.keys(MAPPING.mp.kept).find((k) => k.endsWith("/" + n))]),
].filter((n) => n !== "wtf" && n !== "lfg" && n !== "tdd" && n !== "teach" && n !== "prototype" && n !== "pr" && n !== "implement" && n !== "handoff" && n !== "retro" && n !== "code-review" && n !== "implement-spec");
const generic = ["handoff", "implement", "implement-spec", "code-review", "diagnosing-bugs", "ask-matt", "wait-what", "retro", "setup-matt-pocock-skills", "git-guardrails-claude-code"];
for (const file of walk(SKILLS).filter((f) => f.endsWith(".md") && !f.includes("/references/merged/") && !OVERLAY_SKILLS.has(relative(SKILLS, f).split("/")[0]))) {
  const text = stripMergedLines(stripFences(readFileSync(file, "utf8")));
  for (const n of oldNames) {
    const rx = new RegExp(`(?<![\\w-])${n.replace(/[-]/g, "\\-")}(?![\\w-])`, "g");
    const hits = (text.match(rx) || []).length;
    if (hits && n.startsWith("ce-")) problems.push(`${relative(PLUGIN, file)}: ${hits} leftover reference(s) to ${n}`);
  }
  for (const n of generic) {
    const rx = new RegExp(`(?:/|\`)${n}(?:\`|(?![\\w-]))`, "g");
    const hits = (text.match(rx) || []).length;
    if (hits) problems.push(`${relative(PLUGIN, file)}: ${hits} slash/backtick reference(s) to merged skill ${n}`);
  }
  if (/\bpstack:/.test(text)) problems.push(`${relative(PLUGIN, file)}: pstack: namespace leftover`);
  if (/setup-pstack/.test(text)) problems.push(`${relative(PLUGIN, file)}: setup-pstack leftover`);
}

// 4. manifest agents and hook commands exist
const manifest = JSON.parse(readFileSync(join(PLUGIN, ".claude-plugin", "plugin.json"), "utf8"));
for (const a of manifest.agents || []) if (!existsSync(join(PLUGIN, a))) problems.push(`plugin.json agents: ${a} missing`);
const hooks = JSON.parse(readFileSync(join(PLUGIN, "hooks", "hooks.json"), "utf8"));
for (const group of Object.values(hooks.hooks || {}))
  for (const entry of group)
    for (const h of entry.hooks || []) {
      const m = h.command?.match(/\$\{CLAUDE_PLUGIN_ROOT\}\/([^"\s]+)/);
      if (m) {
        const p = join(PLUGIN, m[1]);
        if (!existsSync(p)) problems.push(`hooks.json: ${m[1]} missing`);
        else if (!(statSync(p).mode & 0o111)) problems.push(`hooks.json: ${m[1]} not executable`);
      }
    }
const marketplace = JSON.parse(readFileSync(join(ROOT, ".claude-plugin", "marketplace.json"), "utf8"));
if (marketplace.plugins[0].name !== manifest.name) problems.push("marketplace plugin name != plugin.json name");
if (marketplace.plugins[0].version !== manifest.version) problems.push("marketplace plugin version != plugin.json version");
if (readFileSync(join(ROOT, "VERSION"), "utf8").trim() !== manifest.version) problems.push("VERSION != plugin.json version");

const skillCount = names.size;
const total = readdirSync(SKILLS, { withFileTypes: true }).filter((e) => e.isDirectory()).length;
for (const w of warnings) console.warn("warn:", w);
if (problems.length) {
  console.error(`FAIL (${problems.length}):\n` + problems.map((p) => "  " + p).join("\n"));
  process.exit(1);
}
console.log(`ok: ${skillCount} skills (${total} dirs), links resolve, no leftover source names, manifests agree`);
