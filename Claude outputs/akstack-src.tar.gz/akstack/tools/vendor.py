#!/usr/bin/env python3
"""Rebuild plugins/akstack from the pinned sources in tools/sources.json, the
selection in tools/mapping.json, and the hand-written files in overlay/.

    python3 tools/vendor.py            # rebuild (clones sources into .cache/sources on first run)
    AKSTACK_SRC_CE=/path/to/clone python3 tools/vendor.py   # use a local checkout for one source

The output directory is deleted and recreated every run, so nothing is edited
there by hand: fix the mapping, the overlay, or the upstream, then rerun.
"""
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PLUGIN = ROOT / "plugins" / "akstack"
OVERLAY = ROOT / "overlay"
CACHE = ROOT / ".cache" / "sources"
SOURCES = json.loads((ROOT / "tools" / "sources.json").read_text())
MAPPING = json.loads((ROOT / "tools" / "mapping.json").read_text())

MERGED_SKILL_FILENAME = "SOURCE.md"  # a vendored skill's SKILL.md is renamed so nothing registers it as a skill
TEXT_SUFFIXES = {".md", ".json", ".sh", ".py", ".js", ".mjs", ".ts", ".txt", ".yaml", ".yml", ".toml", ".html", ".css", ".cmd", ".jsonc", ""}


def log(*a):
    print(*a, file=sys.stderr)


def source_dir(key):
    env = os.environ.get(f"AKSTACK_SRC_{key.upper()}")
    spec = SOURCES[key]
    if env:
        base = Path(env)
    else:
        base = CACHE / key
        if not (base / ".git").exists():
            base.mkdir(parents=True, exist_ok=True)
            subprocess.run(["git", "init", "-q"], cwd=base, check=True)
            subprocess.run(["git", "remote", "add", "origin", spec["repo"]], cwd=base, check=True)
        head = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=base, capture_output=True, text=True).stdout.strip()
        if not head.startswith(spec["sha"]) and not spec["sha"].startswith(head or "?"):
            log(f"fetching {key}@{spec['sha']}")
            subprocess.run(["git", "fetch", "-q", "--depth", "1", "origin", spec["sha"]], cwd=base, check=True)
            subprocess.run(["git", "checkout", "-q", "FETCH_HEAD"], cwd=base, check=True)
    d = base / spec["path"] if spec["path"] != "." else base
    if not d.exists():
        sys.exit(f"source {key}: {d} does not exist")
    return d


def is_text(path: Path):
    if path.suffix not in TEXT_SUFFIXES:
        return False
    try:
        path.read_text(encoding="utf-8")
        return True
    except (UnicodeDecodeError, OSError):
        return False


def rewrite(path: Path, fn):
    if not is_text(path):
        return False
    before = path.read_text(encoding="utf-8")
    after = fn(before)
    if after != before:
        path.write_text(after, encoding="utf-8")
        return True
    return False


def set_frontmatter_name(skill_md: Path, name: str):
    text = skill_md.read_text(encoding="utf-8")
    if not text.startswith("---"):
        sys.exit(f"{skill_md}: no frontmatter")
    new = re.sub(r"^name:\s*.*$", f"name: {name}", text, count=1, flags=re.M)
    skill_md.write_text(new, encoding="utf-8")


def relink_merged(dest: Path):
    """Inside a merged copy, links to its own SKILL.md must follow the rename to SOURCE.md."""
    for p in dest.rglob("*.md"):
        rewrite(p, lambda t: re.sub(r"\]\((?:\./)?SKILL\.md(#[^)]*)?\)", lambda m: f"]({MERGED_SKILL_FILENAME}{m.group(1) or ''})", t))


def copy_tree(src: Path, dest: Path):
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src, dest, ignore=shutil.ignore_patterns(".git", "node_modules", "__pycache__", ".DS_Store"))


# ---------- prose renames for CE and MP material ----------

def prose_renamer():
    pairs = [(k, v) for k, v in MAPPING["prose_renames"].items() if not k.startswith("$")]
    pairs.sort(key=lambda kv: -len(kv[0]))  # longest first so ce-compound-refresh beats ce-compound
    compiled = []
    for old, new in pairs:
        if old == new:
            continue
        o = re.escape(old)
        if old.startswith("ce-"):
            compiled.append((re.compile(rf"(?<![\w-]){o}(?![\w-])"), new))
        else:
            compiled.append((re.compile(rf"/{o}(?![\w-])"), f"/{new}"))
            compiled.append((re.compile(rf"`{o}`"), f"`{new}`"))
            compiled.append((re.compile(rf'"{o}"'), f'"{new}"'))
            compiled.append((re.compile(rf"(?<![\w-]){o}/SKILL\.md"), f"{new}/SKILL.md"))
            compiled.append((re.compile(rf"skills/(?:engineering|productivity|misc)/{o}(?![\w-])"), f"skills/{new}"))

    def apply(text):
        for rx, repl in compiled:
            text = rx.sub(repl, text)
        return text

    return apply


def rename_prose_under(dirs):
    apply = prose_renamer()
    n = 0
    for d in dirs:
        for p in d.rglob("*"):
            if p.is_file() and rewrite(p, apply):
                n += 1
    return n


# ---------- build ----------

def build():
    if PLUGIN.exists():
        shutil.rmtree(PLUGIN)
    PLUGIN.parent.mkdir(parents=True, exist_ok=True)
    merges = []  # (source key, old name, target, note, dest relative)
    kept = []    # (source key, old name, new name)
    vendored_dirs = []

    # 1. pstack backbone
    ps = source_dir("pstack")
    log("pstack from", ps)
    shutil.copytree(ps, PLUGIN, ignore=shutil.ignore_patterns(".codex-plugin", "codex-hooks.json", "README.md", ".git", "node_modules", ".DS_Store"))
    for old, new in MAPPING["pstack"]["renames"].items():
        (PLUGIN / "skills" / old).rename(PLUGIN / "skills" / new)
        set_frontmatter_name(PLUGIN / "skills" / new / "SKILL.md", new)
        kept.append(("pstack", old, new))
    repl = MAPPING["pstack"]["text_replacements"]

    def pstack_text(t):
        for a, b in repl.items():
            t = t.replace(a, b)
        return t

    for p in PLUGIN.rglob("*"):
        if p.is_file():
            rewrite(p, pstack_text)
    for d in (PLUGIN / "skills").iterdir():
        if d.is_dir() and d.name not in MAPPING["pstack"]["renames"].values():
            kept.append(("pstack", d.name, d.name))

    # 2. compound engineering
    ce = source_dir("ce")
    log("ce from", ce)
    for old, new in MAPPING["ce"]["kept"].items():
        dest = PLUGIN / "skills" / new
        copy_tree(ce / old, dest)
        set_frontmatter_name(dest / "SKILL.md", new)
        vendored_dirs.append(dest)
        kept.append(("ce", old, new))
    for old, spec in MAPPING["ce"]["merged"].items():
        dest = PLUGIN / "skills" / spec["target"] / "references" / "merged" / old
        copy_tree(ce / old, dest)
        (dest / "SKILL.md").rename(dest / MERGED_SKILL_FILENAME)
        relink_merged(dest)
        vendored_dirs.append(dest)
        merges.append(("ce", old, spec["target"], spec["note"], dest.relative_to(PLUGIN)))

    # 3. matt pocock
    mp = source_dir("mp")
    log("mp from", mp)
    for old, new in MAPPING["mp"]["kept"].items():
        dest = PLUGIN / "skills" / new
        copy_tree(mp / old, dest)
        set_frontmatter_name(dest / "SKILL.md", new)
        vendored_dirs.append(dest)
        kept.append(("mp", old, new))
    for old, spec in MAPPING["mp"]["merged"].items():
        dest = PLUGIN / "skills" / spec["target"] / "references" / "merged" / Path(old).name
        copy_tree(mp / old, dest)
        (dest / "SKILL.md").rename(dest / MERGED_SKILL_FILENAME)
        relink_merged(dest)
        vendored_dirs.append(dest)
        merges.append(("mp", old, spec["target"], spec["note"], dest.relative_to(PLUGIN)))

    # 4. gstack: only the workflow sections of context-save / context-restore, as provenance for checkpoint
    gs = source_dir("gstack")
    log("gstack from", gs)
    for old, spec in MAPPING["gstack"]["merged"].items():
        text = (gs / old / "SKILL.md").read_text(encoding="utf-8")
        idx = text.find("\n## Detect command")
        body = text[idx + 1:] if idx >= 0 else text
        dest = PLUGIN / "skills" / spec["target"] / "references" / "merged" / f"gstack-{old}"
        dest.mkdir(parents=True, exist_ok=True)
        (dest / MERGED_SKILL_FILENAME).write_text(
            f"# gstack `{old}` (workflow section only)\n\nVendored from {SOURCES['gstack']['repo']} @ {SOURCES['gstack']['sha']}, MIT. "
            "gstack's runtime preamble, telemetry and bin/ helpers are not part of akstack; the checkpoint skill reimplements this flow without them.\n\n" + body,
            encoding="utf-8",
        )
        merges.append(("gstack", old, spec["target"], spec["note"], dest.relative_to(PLUGIN)))

    # 5. prose renames over everything vendored from ce and mp (kept and merged)
    changed = rename_prose_under(vendored_dirs)
    log(f"prose renames touched {changed} files")

    # 6. overlay: hand-written files win
    if (OVERLAY / "plugins" / "akstack").exists():
        shutil.copytree(OVERLAY / "plugins" / "akstack", PLUGIN, dirs_exist_ok=True)
    appends = json.loads((OVERLAY / "append.json").read_text()) if (OVERLAY / "append.json").exists() else {}
    for rel, text in appends.items():
        if rel.startswith("$"):
            continue
        target = PLUGIN / rel
        if not target.exists():
            sys.exit(f"append target missing: {rel}")
        current = target.read_text(encoding="utf-8")
        if text.strip() not in current:
            target.write_text(current.rstrip("\n") + "\n\n" + text.strip() + "\n", encoding="utf-8")

    # 6b. exact replacements for upstream sentences that name dropped skills; each must match exactly once
    replaces = json.loads((OVERLAY / "replace.json").read_text()) if (OVERLAY / "replace.json").exists() else []
    for r in replaces:
        target = PLUGIN / r["file"]
        text = target.read_text(encoding="utf-8")
        if text.count(r["old"]) != 1:
            sys.exit(f"replace.json: expected exactly one match in {r['file']} for: {r['old'][:60]!r} (found {text.count(r['old'])}); upstream changed, update the entry")
        target.write_text(text.replace(r["old"], r["new"]), encoding="utf-8")

    # 7. MERGES.md and docs/skills.md
    write_merges(kept, merges)
    write_skill_index(kept)
    skills = sorted(d.name for d in (PLUGIN / "skills").iterdir() if d.is_dir())
    log(f"built {len(skills)} skills")
    return skills


GROUPS = [
    ("Entry point and execution", ["poteto-mode", "lfg", "setup-akstack", "setup-tracker"]),
    ("Scope and plan", ["brainstorm", "plan", "doc-review", "ideate", "grilling", "grill-me", "grill-with-docs", "to-spec", "to-tickets", "wayfinder", "triage", "to-questionnaire", "figure-it-out", "architect", "arena", "blast-radius", "pov", "research"]),
    ("Design and code quality", ["codebase-design", "domain-modeling", "improve-codebase-architecture", "typescript-best-practices", "tdd", "deslop", "unslop", "no-comments", "technical-writing", "writing-for-agents", "make-pr-easy-to-review"]),
    ("Verify and review", ["verify-web", "create-verification-skill", "maintain-verification-skill", "interrogate", "thermo-nuclear-code-quality-review", "polish", "show-me-your-work"]),
    ("Ship", ["babysit", "get-pr-comments", "fix-ci", "fix-merge-conflicts", "worktree", "git-guardrails"]),
    ("Understand and remember", ["how", "why", "teach", "wtf", "bro", "recall", "checkpoint", "compound", "compound-refresh", "reflect", "automate-me", "what-did-i-get-done", "wizard", "swarm"]),
]


def write_skill_index(kept):
    skills = {}
    for d in sorted((PLUGIN / "skills").iterdir()):
        if not d.is_dir():
            continue
        text = (d / "SKILL.md").read_text(encoding="utf-8")
        m = re.search(r'^description:\s*"?(.*?)"?\s*$', text, re.M)
        desc = (m.group(1) if m else "").strip()
        first = re.split(r"(?<=[.!?])\s", desc, maxsplit=1)[0]
        skills[d.name] = first
    origin = {}
    for src, old, new in kept:
        origin[new] = src
    label = {"pstack": "pstack", "ce": "compound engineering", "mp": "matt pocock"}
    lines = ["# Skills", "", f"{len(skills)} skills, `/akstack:<name>`. Generated by `tools/vendor.py` from each skill's description; the origin column names where it came from (merged skills list their sources in MERGES.md).", ""]
    placed = set()
    for title, members in GROUPS:
        lines += [f"## {title}", "", "| skill | use it when | origin |", "| --- | --- | --- |"]
        for n in members:
            if n in skills:
                lines.append(f"| `/{n}` | {skills[n]} | {label.get(origin.get(n), 'akstack')} |")
                placed.add(n)
        lines.append("")
    principles = [n for n in skills if n.startswith("principle-")]
    lines += ["## Principles (referenced by poteto-mode, not invoked directly)", "", ", ".join(f"`{n}`" for n in principles), ""]
    placed.update(principles)
    rest = [n for n in skills if n not in placed]
    if rest:
        lines += ["## Other", "", "| skill | use it when | origin |", "| --- | --- | --- |"] + [f"| `/{n}` | {skills[n]} | {label.get(origin.get(n), 'akstack')} |" for n in rest] + [""]
    (ROOT / "docs").mkdir(exist_ok=True)
    (ROOT / "docs" / "skills.md").write_text("\n".join(lines), encoding="utf-8")


def write_merges(kept, merges):
    lines = ["# MERGES", "", "Generated by `tools/vendor.py` from `tools/mapping.json`. One entry point per job; where two sources did the same job, the pstack name is the entry point and the other source's files sit under `references/merged/<original name>/` inside the target (its `SKILL.md` renamed to `SOURCE.md` so it never registers as a second skill).", "", "## Merged into a single entry point", "", "| Source | Original | Now | What was kept |", "| --- | --- | --- | --- |"]
    for src, old, target, note, rel in sorted(merges, key=lambda m: (m[2], m[0], m[1])):
        lines.append(f"| {src} | `{old}` | `{target}` | {note} (`{rel}`) |")
    lines += ["", "## Renamed", "", "| Source | Original | Now |", "| --- | --- | --- |"]
    for src, old, new in sorted(kept):
        if old != new and Path(old).name != new:
            lines.append(f"| {src} | `{old}` | `{new}` |")
    lines += ["", "## Dropped (not vendored)", ""]
    for src in ("ce", "mp"):
        lines.append(f"- {src}: " + ", ".join(f"`{d}`" for d in MAPPING[src]["dropped"]))
    lines += ["", "## Kept as-is", "", "- pstack: every skill in the fork, with `setup-pstack` renamed to `setup-akstack` and the `pstack:` namespace rewritten to `akstack:`.",
              "- ce: " + ", ".join(f"`{n}`" for n in MAPPING["ce"]["kept"].values()) + " (the `ce-` prefix is dropped).",
              "- mp: " + ", ".join(f"`{n}`" for n in MAPPING["mp"]["kept"].values()) + ".", ""]
    (ROOT / "MERGES.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    build()
