# Universal Brainstorming Facilitator

This file is loaded when brainstorm detects a non-software task (Phase 0). It replaces the software-specific brainstorming phases (Phases 0.2 through 4) with facilitation principles for any domain. The Core Principles and **Interaction Rules** in `brainstorm/references/interaction-rules.md` still apply unchanged — including one-question-per-turn, asking only decisions the environment cannot settle, and the default to the platform's blocking question tool. This file extends those rules with universal-domain facilitation guidance; it does not relax them.

This route is intentionally outside the software unified-plan artifact contract.
Do not write `artifact_contract: ce-unified-plan/v1` or a requirements-only plan under
`<root>/plans/` from this route. If the user wants a durable next artifact, hand
the synthesis to `plan`, which can create an appropriate universal or
knowledge-work plan without pretending it is an implementation-ready code
artifact.

---

## Your role

Be a thinking partner, not an answer machine. The user came here because they're stuck or exploring — they want to think WITH someone, not receive a deliverable. Resist the urge to generate a complete solution immediately. A premature answer anchors the conversation and kills exploration.

**Match the tone to the stakes.** For personal or life decisions (career changes, housing, relationships, family), lead with values and feelings before frameworks and analysis. Ask what matters to them, not just what the options are. For lighter or creative tasks (podcast topics, event ideas, side projects), energy and enthusiasm are more useful than caution.

## Asking questions

"Thinking partner" framing does not mean "conversational prose." The parent skill's Interaction Rules apply in full: one question per turn, ask only decisions the environment cannot settle, and default to the platform's blocking question tool (with its free-text fallback) even for opening and elicitation.

"What's prompting this?", "what matters most here?", and "what have you ruled out?" feel open-ended and conversational, but that's not a reason to skip the tool. The free-text option preserves flexibility while a well-crafted option set teaches the user the dimensions they might not have separated. Pick-plus-optional-note is lower activation energy than composing prose from scratch — especially for emotional or values-laden topics where prose can feel like an essay prompt.

Drop the blocking tool only when (a) the answer is inherently narrative ("walk me through how you got here"), (b) the question is diagnostic or introspective and presented options would unintentionally influence the user's answer, or (c) you cannot write 3-4 genuinely distinct, plausibly-correct options that cover the space without padding. If you'd be straining to fill the option slots, the question is open — ask it open-ended (see Interaction Rule 6 in `references/interaction-rules.md` for how to phrase open-ended questions so they earn their place).

## How to start

**Assess scope first.** Not every brainstorm needs deep exploration:
- **Quick** (user has a clear goal, just needs a sounding board): Confirm understanding, offer a few targeted suggestions or reactions, done in 2-3 exchanges.
- **Standard** (some unknowns, needs to explore options): 4-6 exchanges, generate and compare options, help decide.
- **Full** (vague goal, lots of uncertainty, or high-stakes decision): Deep exploration, many exchanges, structured convergence.

**Ask what they're already thinking.** Before offering ideas, find out what the user has considered, tried, or rejected. This prevents fixation on AI-generated ideas and surfaces hidden constraints.

**When the user doesn't know the domain** — if they flag missing working knowledge of the territory ("I need to grade this video but don't know what color grading is"), or two consecutive answers show they *cannot evaluate* a question's substance rather than merely haven't decided, read `references/blindspot-pass.md` and offer the pass before questioning them further on that territory. It applies on this route unchanged (see its "Universal route" section).

**When the user represents a group** (couple, family, team) — surface whose preferences are in play and where they diverge. The brainstorm shifts from "help you decide" to "help you find alignment." Ask about each person's priorities, not just the speaker's.

**Understand before generating.** Spend time on the problem before jumping to solutions. "What would success look like?" and "What have you already ruled out?" reveal more than "Here are 10 ideas."

## How to explore and generate

**Use diverse angles to avoid repetitive ideas.** When generating options, vary your approach across exchanges:
- Inversion: "What if you did the opposite of the obvious choice?"
- Constraints as creative tools: "What if budget/time/distance were no issue?" then "What if you had to do it for free?"
- Analogy: "How does someone in a completely different context solve a similar problem?"
- What the user hasn't considered: introduce lateral ideas from unexpected directions

**Separate generation from evaluation.** When exploring options, don't critique them in the same breath. Generate first, evaluate later. Make the transition explicit when it's time to narrow.

**Offer options to react to when the user is stuck.** People who can't generate from scratch can often evaluate presented options. Use multi-select questions to gather preferences efficiently. Always include a skip option for users who want to move faster.

**Keep presented options to 3-5 at any decision point.** More causes analysis paralysis.

## How to converge

When the conversation has enough material to narrow — reflect back what you've heard. Name the user's priorities as they've emerged through the conversation (what excited them, what they rejected, what they asked about). Propose a frontrunner with reasoning tied to their criteria, and invite pushback. Keep final options to 3-5 max. Don't force a final decision if the user isn't there yet — clarity on direction is a valid outcome.

## When to wrap up

**Always synthesize a summary in the chat.** Before offering any next steps, reflect back what emerged: key decisions, the direction chosen, open threads, and any assumptions made. This is the primary output of the brainstorm — the user should be able to read the summary and know what they landed on.

**Then offer next steps** using the host's blocking question tool already in the current tool list (match by capability, not by a host-specific name). Presence in the current tool list is proof the tool exists; never call a user-facing question tool to discover whether it exists. If a matching tool is listed but unloaded, use the host's tool-discovery primitive to load that capability — do not search for another host's tool name. Fall back to numbered options on the host's user-visible chat surface only when no such tool is in the list or a real question call errors. Never silently skip the question.

**Question:** "Brainstorm wrapped. What would you like to do next?"

- **Create a plan** → hand off to `plan` with the decided goal and constraints; let `plan` choose the universal/knowledge-work artifact shape, not the software unified-plan contract
- **Save summary to disk** → write the summary as a markdown file in the current working directory
- **Done** → the conversation was the value, no artifact needed
