---
name: deslop
description: Remove AI-generated code slop and clean up code style
---

# Remove AI code slop

Check the diff against main and remove AI-generated slop introduced in the branch.

## Focus Areas

- Extra comments that are unnecessary or inconsistent with local style
- Defensive checks or try/catch blocks that are abnormal for trusted code paths
- Casts to `any` used only to bypass type issues
- Deeply nested code that should be simplified with early returns
- Other patterns inconsistent with the file and surrounding codebase

## Guardrails

- Keep behavior unchanged unless fixing a clear bug.
- Prefer minimal, focused edits over broad rewrites.
- Keep the final summary concise (1-3 sentences).

## Merged sources

Compound Engineering's `ce-simplify-code` ([references/merged/ce-simplify-code/SOURCE.md](references/merged/ce-simplify-code/SOURCE.md)) is the post-implementation pass: simplify settled, recently changed code for clarity, reuse and efficiency while preserving behavior, before review. Run it on a branch diff after a feature lands and before `interrogate`.
