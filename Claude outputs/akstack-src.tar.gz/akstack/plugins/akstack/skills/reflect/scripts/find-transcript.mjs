#!/usr/bin/env node
// Locate the transcript whose opening user prompt carries a fragment.
//
//   node find-transcript.mjs <projects-dir> <opening-prompt-fragment>
//
// Prints the newest matching path, or exits 1 with "no transcript". Covers the
// three layouts under one per-project directory: flat <id>.jsonl, nested
// <id>/<id>.jsonl, and subagent <id>/subagents/<child>.jsonl. Each candidate is
// streamed line by line and abandoned at its first typed `user` record; the
// first line is session metadata and files run to megabytes.
import { createReadStream, readdirSync, realpathSync, statSync } from "node:fs";
import { join } from "node:path";
import process from "node:process";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";

export function candidates(projectsDir, maxDepth = 2) {
  const files = [];
  const walk = (dir, depth) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const full = join(dir, entry.name);
      if (entry.isFile() && entry.name.endsWith(".jsonl")) files.push(full);
      else if (entry.isDirectory() && depth < maxDepth) walk(full, depth + 1);
    }
  };
  walk(projectsDir, 0);
  return files
    .map((path) => ({ path, mtime: statSync(path).mtimeMs }))
    .sort((a, b) => b.mtime - a.mtime)
    .map(({ path }) => path);
}

function text(content) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .filter((block) => typeof block?.text === "string")
      .map((block) => block.text)
      .join("\n");
  }
  return null;
}

// `user` records Claude Code writes for a local command (/clear, !cmd) and its
// output, not a prompt the user typed. A skill invocation leads with
// <command-message> and is kept: its <command-args> carry what the user typed.
const LOCAL_COMMAND = /^\s*<(?:command-name|local-command-stdout|bash-input)>/u;

export async function openingPrompt(path) {
  const stream = createReadStream(path, { encoding: "utf8" });
  const lines = createInterface({ input: stream, crlfDelay: Infinity });
  try {
    for await (const line of lines) {
      let record;
      try {
        record = JSON.parse(line);
      } catch {
        continue;
      }
      if (record?.type !== "user" || record.isMeta) continue;
      const prompt = text(record.message?.content);
      if (prompt && !LOCAL_COMMAND.test(prompt)) return prompt;
    }
  } finally {
    lines.close();
    stream.destroy();
  }
  return null;
}

export async function findTranscript(projectsDir, fragment) {
  for (const path of candidates(projectsDir)) {
    const prompt = await openingPrompt(path);
    if (prompt?.includes(fragment)) return path;
  }
  return null;
}

async function main(argv) {
  const [projectsDir, fragment] = argv;
  if (!projectsDir || !fragment) {
    console.error("usage: find-transcript.mjs <projects-dir> <opening-prompt-fragment>");
    return 2;
  }
  const path = await findTranscript(projectsDir, fragment);
  if (!path) {
    console.error(`no transcript under ${projectsDir} opens with ${JSON.stringify(fragment)}`);
    return 1;
  }
  console.log(path);
  return 0;
}

// node leaves argv[1] unresolved and may set it to a non-file (`node -e ... arg`).
function invokedDirectly() {
  if (!process.argv[1]) return false;
  try {
    return fileURLToPath(import.meta.url) === realpathSync(process.argv[1]);
  } catch {
    return false;
  }
}

if (invokedDirectly()) {
  process.exitCode = await main(process.argv.slice(2));
}
