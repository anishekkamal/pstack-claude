# akstack

One Claude Code plugin with the engineering skills I actually use, merged so there is one name per job: [pstack](https://github.com/cursor/plugins/tree/main/pstack) (via [Michael Denyer's port](https://github.com/michael-denyer/pstack-claude) and [my fork](https://github.com/anishekkamal/pstack-claude) that adds the `verify-web` harness) as the backbone, [Compound Engineering](https://github.com/EveryInc/compound-engineering-plugin)'s brainstorm, plan, review and compound loop, [Matt Pocock's skills](https://github.com/mattpocock/skills) for grilling, specs, tickets, domain modelling and TDD, and a `checkpoint` skill that carries [gstack](https://github.com/garrytan/gstack)'s save and restore flow on top of pstack's resume store. All four sources are MIT; credits are in [NOTICE.md](NOTICE.md), every merge in [MERGES.md](MERGES.md), every skill in [docs/skills.md](docs/skills.md).

The structure is pstack's because I follow how Lauren Tan works: `poteto-mode` is the entry point and routes to a playbook, principles shape how code gets written, and nothing is called done without evidence from the real artifact.

## Install

```text
/plugin marketplace add anishekkamal/akstack
/plugin install akstack@akstack
```

Every skill is `/akstack:<name>`. A session-start hook tells the agent to route non-trivial work through `akstack:poteto-mode`, the same way pstack does. Do not install pstack, Compound Engineering or Matt Pocock's plugin beside this one; you would get every skill twice and the router would have to guess.

Optional, once per machine: `/akstack:setup-akstack` for model and effort overrides. Once per repo: `/akstack:verify-web set up verification for this repo` on a web app, and `/akstack:setup-tracker` if you use the spec and ticket flows against an issue tracker.

## The loop

Most work starts with one line to `poteto-mode` and ends with a verdict and a PR:

```text
/akstack:poteto-mode fix the search filter resetting when I change pages. show me the failing and passing evidence.
```

When the shape of the work is not settled yet, the front half is Compound Engineering's and Matt Pocock's:

| I want to | Skill |
| --- | --- |
| Scope a vague idea into requirements | `brainstorm`, then `plan` |
| Stress-test a decision before building | `grilling` (or `grill-with-docs` to leave ADRs and a glossary behind) |
| Turn a conversation into tracker items | `to-spec`, `to-tickets`, `wayfinder` for very large work |
| Build, debug, refactor, prototype | `poteto-mode` (its playbooks), `tdd` |
| Settle a design that crosses a boundary | `architect`, `codebase-design`, `domain-modeling` |
| Prove a web change works | the repo's `verify` skill, created by `verify-web` |
| Review before merge | `interrogate` (reviewer panel), `thermo-nuclear-code-quality-review` |
| Open and land the PR | `poteto-mode` opening-a-pr playbook, `babysit`, `get-pr-comments` |
| Keep what was learned | `compound` (repo learning), `reflect` (skill improvements) |
| Pause or hand off | `checkpoint` |
| Everything, hands-off | `lfg` |

The rest of the catalog, grouped, is in [docs/skills.md](docs/skills.md). [docs/verify-web.md](docs/verify-web.md) covers the verification harness and the trust ladder for deciding where each agent correction belongs.

## How the merge works

When two sources did the same job, the pstack name is the entry point and the other source's files sit under `references/merged/<original name>/` inside it, with a short pointer in the target so the agent knows when to read them. Nothing was thrown away silently; the mapping is in [`tools/mapping.json`](tools/mapping.json) and the generated [MERGES.md](MERGES.md). Compound Engineering's `ce-` prefix is dropped so every skill reads the same way. Every-specific tooling (Proof, Riffrec, product pulse) and Matt Pocock's course scaffolding were left out.

## Keeping up with the sources

`plugins/akstack/` is generated. To take an upstream update, bump the `sha` in [`tools/sources.json`](tools/sources.json), run `python3 tools/vendor.py` (it clones each source at its pin into `.cache/sources/`), then `node tools/validate.mjs`, and review the diff. Hand-written files live in `overlay/` and win on every rebuild; sentence-level edits to vendored files live in `overlay/replace.json` and fail loudly when the upstream sentence changes.

## Layout

```text
.claude-plugin/marketplace.json   the marketplace (name: akstack)
plugins/akstack/                  the plugin, generated: skills/, agents/, effort-agents/, hooks/, models.json
overlay/                          hand-written skills (checkpoint, lfg, tdd, wtf, teach), manifest, hook text, appends, replacements
tools/                            sources.json (pins), mapping.json (selection), vendor.py (build), validate.mjs (checks)
docs/                             skills.md (generated index), verify-web.md (harness guide)
```

## Data handling

No server, no telemetry. Skills read what you point them at and send it to your model provider; scripts run locally; PR tools use your GitHub CLI login. `verify-web` keeps evidence in the repo's `.claude/skills/verify/evidence/`, gitignored.

## License

MIT, © 2026 Anishek Kamal, for this assembly and the hand-written skills. Each vendored source keeps its own MIT copyright; see [NOTICE.md](NOTICE.md).
