# CHANGES

## 0.1.0 - first assembly

pstack (Anishek's fork at `e725e28`, which adds the `verify-web` harness) as the backbone; Compound Engineering `752b0bc`; Matt Pocock's skills `d81f3a1`; gstack `7fca42a` for the checkpoint flow. 83 skills in one namespace. Merges and renames are in `MERGES.md`; the build is reproducible with `tools/vendor.py`.

Hand-written: `checkpoint` (save, list, restore on pstack's resume store, with the handoff document shape), `lfg` (Compound Engineering's pipeline re-pointed at akstack skills), `tdd` (pstack's regression workflow plus Matt Pocock's seams, anti-patterns and loop rules), `wtf` (CE's wtf plus Matt Pocock's wait-what), `teach` (pstack's explain mode plus Matt Pocock's learning-workspace mode), the plugin manifest and the session-start text.
