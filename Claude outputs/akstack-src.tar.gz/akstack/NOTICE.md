# Third-party notices

akstack is MIT (LICENSE). It vendors skills from the four MIT projects below, renamed and cross-referenced as `MERGES.md` records; the pinned revisions are in `tools/sources.json`. Each source's copyright and permission notice apply to the files taken from it.

## pstack

Original pstack © 2026 Lauren Tan (poteto), MIT: https://github.com/cursor/plugins/tree/main/pstack. Imported cursor-team-kit skills © 2026 Cursor, MIT.
Claude Code port © 2026 Michael Denyer, MIT: https://github.com/michael-denyer/pstack-claude.
verify-web harness © 2026 Anishek Kamal, MIT: https://github.com/anishekkamal/pstack-claude.

Vendored as the whole plugin backbone (`plugins/akstack/skills/*` except the directories listed under the other sources, `agents/`, `effort-agents/`, `hooks/`, `models.json`, `assets/`). Changes: `setup-pstack` renamed `setup-akstack`, the `pstack:` skill namespace rewritten to `akstack:`, the models sheet renamed `akstack-models.md`, the session-start text rewritten, and "Merged sources" pointers appended to the skills and playbooks named in `MERGES.md`. The port's `LICENSE`, `LICENSE-cursor-team-kit` and `NOTICE` texts are kept at `plugins/akstack/skills/poteto-mode/references/licenses/`.

## Compound Engineering

© Kieran Klaassen and Trevin Chow (Every), MIT: https://github.com/EveryInc/compound-engineering-plugin.

Vendored: `brainstorm`, `plan`, `doc-review`, `ideate`, `compound`, `compound-refresh`, `pov`, `polish`, `worktree` (the `ce-` prefix dropped, cross-references renamed), and, as merged references under other skills, `ce-debug`, `ce-code-review`, `ce-commit`, `ce-commit-push-pr`, `ce-babysit-pr`, `ce-resolve-pr-feedback`, `ce-handoff`, `ce-prototype`, `ce-bakeoff`, `wtf`, `ce-noslop`, `ce-simplify-code`, `ce-optimize`, `ce-explain`, `ce-work`, `lfg`, `ce-test-browser`, `ce-dogfood`. The `lfg` and `wtf` skills in akstack are rewrites that credit their originals.

## Skills For Real Engineers

© Matt Pocock, MIT: https://github.com/mattpocock/skills.

Vendored: `grilling`, `grill-me`, `grill-with-docs`, `to-spec`, `to-tickets`, `wayfinder`, `triage`, `domain-modeling`, `codebase-design`, `improve-codebase-architecture`, `research`, `wizard`, `to-questionnaire`, `writing-for-agents`, `git-guardrails-claude-code` (as `git-guardrails`), `setup-matt-pocock-skills` (as `setup-tracker`), and, as merged references, `diagnosing-bugs`, `code-review`, `pr`, `handoff`, `tdd`, `prototype`, `retro`, `teach`, `implement`, `implement-spec`, `ask-matt`, `wait-what`. The `tdd` and `teach` skills in akstack merge his text with pstack's.

## gstack

© 2026 Garry Tan, MIT: https://github.com/garrytan/gstack.

Only the `context-save` and `context-restore` workflow sections are kept, as references under `checkpoint`; the `checkpoint` skill reimplements that save, list and restore flow on pstack's resume store without gstack's runtime, preamble or telemetry.
